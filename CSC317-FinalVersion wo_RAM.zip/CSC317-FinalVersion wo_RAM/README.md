CSC317-Project-1
================

Basic 32-Bit Processor in Verilog HDL
